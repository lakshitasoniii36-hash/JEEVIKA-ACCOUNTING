// ═══════════════════════════════════════════════════════
// JEEVIKA ERP — PAYMENT ENTRY: MOCK DATA
// ═══════════════════════════════════════════════════════

var PaymentEntryMockData = (function () {

  var cashBankAccounts = [
    { code: 'B001', name: 'HDFC Bank A/c 1234' },
    { code: 'B002', name: 'SBI Bank A/c 5678' },
    { code: 'C001', name: 'Cash in Hand' }
  ];

  var expenseAccounts = [
    { code: 'E001', name: 'Printing & Stationery' },
    { code: 'E002', name: 'Repairs & Maintenance' },
    { code: 'E003', name: 'Electricity Charges' },
    { code: 'E004', name: 'Security Services' },
    { code: 'E005', name: 'Professional Fees' }
  ];

  var vendors = [
    { code: 'VND-001', name: 'Shree Sai Elevators Pvt Ltd', panNo: 'AABCS9876Q', tdsPercent: 2.0, tdsSection: '194C', gstNo: '27AABCS9876Q1Z5', contactNo: '9820412345', remark: 'Lift Maintenance - includes 24/7 breakdown assistance.' },
    { code: 'VND-002', name: 'Clean-All Facility Services', panNo: 'ACAFS1122C', tdsPercent: 2.0, tdsSection: '194C', gstNo: '27ACAFS1122C2Z9', contactNo: '9321055667', remark: 'Housekeeping - Supplies 3 sweepers daily.' },
    { code: 'VND-003', name: 'Vijay Retainer Services', panNo: 'AVKPS9988D', tdsPercent: 0.0, tdsSection: 'None', gstNo: '', contactNo: '9821433445', remark: 'Plumber / Electrician - Monthly maintenance retainer.' },
    { code: 'VND-004', name: 'SecureGuard Agency', panNo: 'BSGPA4455K', tdsPercent: 2.0, tdsSection: '194C', gstNo: '27BSGPA4455K3Z7', contactNo: '9876001234', remark: 'Security Guard services.' },
    { code: 'VND-005', name: 'GreenTech Garden Services', panNo: 'CGTGS6677L', tdsPercent: 1.0, tdsSection: '194C', gstNo: '', contactNo: '9988776655', remark: 'Gardening and landscaping contractor.' }
  ];

  var membersList = [
    { code: 'M001', name: 'Rahul Sharma', flatNo: 'A-101', contactNo: '9876543210', panNo: 'ABCPS1234Q', tanNo: 'MUMA12345E', tdsPercent: 0.0 },
    { code: 'M002', name: 'Priya Desai', flatNo: 'A-102', contactNo: '9876543211', panNo: 'BCDPD2345R', tanNo: '', tdsPercent: 0.0 },
    { code: 'M003', name: 'Amit Patel', flatNo: 'B-201', contactNo: '9876543212', panNo: 'CDEAP3456S', tanNo: '', tdsPercent: 0.0 },
    { code: 'M004', name: 'Sneha Kapoor', flatNo: 'B-202', contactNo: '9876543213', panNo: 'DEFSK4567T', tanNo: 'MUMB67890F', tdsPercent: 0.0 },
    { code: 'M005', name: 'Vikram Singh', flatNo: 'C-301', contactNo: '9876543214', panNo: 'EFGVS5678U', tanNo: '', tdsPercent: 0.0 }
  ];

  var payments = (function() {
    var stored = localStorage.getItem('jeevika_tx_payment');
    if (stored) {
      try {
        var parsed = JSON.parse(stored);
        if (Array.isArray(parsed)) return parsed;
      } catch(e) {}
    }
    return [];
  })();
  var currentId = payments.length ? Math.max.apply(null, payments.map(function(item) {
    var num = parseInt((item.id || '').replace('PV-ID-', ''));
    return isNaN(num) ? 0 : num;
  })) + 1 : 1;

  function generateMockPayments() {
    if (payments.length > 0) return;
    for (var i = 1; i <= 15; i++) {
      var amt = 2000 + (i * 450);
      var cb = cashBankAccounts[i % cashBankAccounts.length];
      var isCash = cb.code.startsWith('C');
      payments.push({
        id: 'PV-ID-' + i,
        voucherNo: 'PV/25/' + String(100 + i).padStart(3, '0'),
        voucherDate: '2025-05-' + String((i % 28) + 1).padStart(2, '0'),
        voucherType: 'Payment',
        cashBankCode: cb.code,
        cashBankName: cb.name,
        amount: amt,
        chqNo: isCash ? '' : '00' + (8877 + i),
        chqDate: isCash ? '' : '2025-05-' + String((i % 28) + 1).padStart(2, '0'),
        billNo: 'BILL/25/' + (400 + i),
        personName: 'Vendor ' + String.fromCharCode(65 + i),
        particular1: 'Payment for services rendered',
        particular2: 'Approved by committee',
        lineItems: [
          { sr: 1, code: expenseAccounts[i % expenseAccounts.length].code, accountName: expenseAccounts[i % expenseAccounts.length].name, debit: amt, credit: 0 }
        ],
        checks: {
          noCommSign: i % 3 === 0,
          noRecSign: false,
          noSupp: i % 5 === 0,
          noMeetApp: false,
          noTds: false,
          noVch: false,
          excessCash: false
        },
        remark1: '',
        remark2: '',
        status: 'Posted'
      });
      currentId++;
    }
  }
  generateMockPayments();
  if (!localStorage.getItem('jeevika_tx_payment')) {
    localStorage.setItem('jeevika_tx_payment', JSON.stringify(payments));
  }

  return {
    getCashBankAccounts: function() { return cashBankAccounts; },
    getAccounts: function() { return expenseAccounts; },
    getVendors: function() { return vendors; },
    getMembersList: function() { return membersList; },
    getPayments: function() { return payments; },
    getNextVoucherNo: function() { return 'PV/25/' + String(100 + currentId).padStart(3, '0'); },
    savePayment: function(obj) {
      if(!obj.id) {
        obj.id = 'PV-ID-' + currentId;
        currentId++;
        payments.push(obj);
      } else {
        var idx = payments.findIndex(function(p) { return p.id === obj.id; });
        if(idx > -1) payments[idx] = obj;
      }
    },
    deletePayment: function(voucherNo) {
      payments = payments.filter(function(p) { return p.voucherNo !== voucherNo; });
    }
  };
})();

// JEEVIKA ERP — CLIENT-SIDE PERSISTENCE WRAPPER
(function() {
  if (typeof PaymentEntryMockData === 'undefined') return;
  if (typeof PaymentEntryMockData.savePayment === 'function') {
    var orig_savePayment = PaymentEntryMockData.savePayment;
    PaymentEntryMockData.savePayment = function() {
      var res = orig_savePayment.apply(this, arguments);
      // Retrieve the updated array from the private scope if possible or serialize the modified array
      // Since it mutates the array in-place, we can get it via the getter function
      var dataToSave = [];
      if (typeof PaymentEntryMockData.getPayments === 'function') {
        dataToSave = PaymentEntryMockData.getPayments();
      } else if (typeof PaymentEntryMockData.getVouchers === 'function') {
        dataToSave = PaymentEntryMockData.getVouchers();
      } else if (typeof PaymentEntryMockData.getEntries === 'function') {
        dataToSave = PaymentEntryMockData.getEntries();
      } else if (typeof PaymentEntryMockData.getNotes === 'function') {
        dataToSave = PaymentEntryMockData.getNotes();
      } else if (typeof PaymentEntryMockData.getTransfers === 'function') {
        dataToSave = PaymentEntryMockData.getTransfers();
      } else if (typeof PaymentEntryMockData.getReceipts === 'function') {
        dataToSave = PaymentEntryMockData.getReceipts();
      } else if (typeof PaymentEntryMockData.getReversals === 'function') {
        dataToSave = PaymentEntryMockData.getReversals();
      } else if (typeof PaymentEntryMockData.getPayments === 'function') {
        dataToSave = PaymentEntryMockData.getPayments();
      } else if (typeof PaymentEntryMockData.getContras === 'function') {
        dataToSave = PaymentEntryMockData.getContras();
      }
      localStorage.setItem('jeevika_tx_payment', JSON.stringify(dataToSave));
      return res;
    };
  }
  if (typeof PaymentEntryMockData.deletePayment === 'function') {
    var orig_deletePayment = PaymentEntryMockData.deletePayment;
    PaymentEntryMockData.deletePayment = function() {
      var res = orig_deletePayment.apply(this, arguments);
      // Retrieve the updated array from the private scope if possible or serialize the modified array
      // Since it mutates the array in-place, we can get it via the getter function
      var dataToSave = [];
      if (typeof PaymentEntryMockData.getPayments === 'function') {
        dataToSave = PaymentEntryMockData.getPayments();
      } else if (typeof PaymentEntryMockData.getVouchers === 'function') {
        dataToSave = PaymentEntryMockData.getVouchers();
      } else if (typeof PaymentEntryMockData.getEntries === 'function') {
        dataToSave = PaymentEntryMockData.getEntries();
      } else if (typeof PaymentEntryMockData.getNotes === 'function') {
        dataToSave = PaymentEntryMockData.getNotes();
      } else if (typeof PaymentEntryMockData.getTransfers === 'function') {
        dataToSave = PaymentEntryMockData.getTransfers();
      } else if (typeof PaymentEntryMockData.getReceipts === 'function') {
        dataToSave = PaymentEntryMockData.getReceipts();
      } else if (typeof PaymentEntryMockData.getReversals === 'function') {
        dataToSave = PaymentEntryMockData.getReversals();
      } else if (typeof PaymentEntryMockData.getPayments === 'function') {
        dataToSave = PaymentEntryMockData.getPayments();
      } else if (typeof PaymentEntryMockData.getContras === 'function') {
        dataToSave = PaymentEntryMockData.getContras();
      }
      localStorage.setItem('jeevika_tx_payment', JSON.stringify(dataToSave));
      return res;
    };
  }
})();
